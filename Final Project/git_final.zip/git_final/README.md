initial readme file
